import java.io.*;

public class CSVLogger {

    private static final String FILE_NAME = "co2_readings.csv";
    private static final String HEADER = "timestamp,userID,postcode,CO2 ppm";

    public static synchronized void writeRecord(DataRecord record) {
        File file = new File(FILE_NAME);

        try {
            //if file does not exist create it
            if (!file.exists() || file.length() == 0) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                    writer.write(HEADER); //write header
                    writer.newLine(); //new line
                    writer.write(record.toCSV());
                    writer.newLine(); //new line
                }
            }
            //else append the record
            else {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                    writer.write(record.toCSV());
                    writer.newLine();
                }
            }

        } catch (IOException e) {
            System.err.println("CSV write error: " + e.getMessage());
        }
    }
}
