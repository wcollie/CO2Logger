<?php
include("auth.php");
$user_id = $_SESSION['user_id'];

/*database connection*/

$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "Student_Mental_Health";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}



$message = "";

/*booking form*/

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $session_date = $_POST['session_date'];
    $session_time = $_POST['session_time'];
    $notes = $_POST['notes'];

    /* Prevent double booking */

    $check = $conn->prepare("SELECT * FROM therapy_bookings
                             WHERE session_date = ?
                             AND session_time = ?");

    $check->bind_param("ss", $session_date, $session_time);
    $check->execute();

    $result = $check->get_result();

    if($result->num_rows > 0){

        $message = "This session time has already been booked.";

    }else{

        $stmt = $conn->prepare("INSERT INTO therapy_bookings
        (user_id, session_date, session_time, notes)
        VALUES (?, ?, ?, ?)");

        $stmt->bind_param(
            "isss",
            $user_id,
            $session_date,
            $session_time,
            $notes
        );

        if($stmt->execute()){
            $message = "Therapy session booked successfully!";
        }else{
            $message = "Booking failed.";
        }

        $stmt->close();
    }

    $check->close();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Therapy Booking</title>
    <link rel="stylesheet" href="therapyStyle.css">
    <link rel="stylesheet" href="style.css">
    <?php include 'navbar.php'; ?>
</head>

<body>


    <div class="booking-container">

        <h1>Book a Therapy Session</h1>

        <?php
        if($message != ""){
            echo "<div class='message'>$message</div>";
        }
        ?>

        <form method="POST" action="">

            <label>Select Date</label>
            <input type="date" name="session_date" required>

            <label>Select Time</label>

            <select name="session_time" required>

                <option value="">Choose Time</option>

                <option value="09:00:00">09:00 AM</option>
                <option value="10:00:00">10:00 AM</option>
                <option value="11:00:00">11:00 AM</option>
                <option value="12:00:00">12:00 PM</option>
                <option value="13:00:00">01:00 PM</option>
                <option value="14:00:00">02:00 PM</option>
                <option value="15:00:00">03:00 PM</option>
                <option value="16:00:00">04:00 PM</option>

            </select>

            <label>Notes</label>
            <textarea name="notes" rows="5"></textarea>

            <button type="submit" class="button">
                Book Session
            </button>

        </form>

    </div>

</body>

</html>