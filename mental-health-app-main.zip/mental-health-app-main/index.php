<?php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Welcome</title>
    <link rel="stylesheet" href="startUpStyle.css">
</head>

<body>

<div class="card">

    <h1>Welcome to the Student Mental Health App</h1>
    <h2>A safe space built for you</h2>

    <a href="loginForm.php" class="button">Login</a>
    <a href="registerForm.php" class="button">Register</a>

</div>

</body>
</html>