<?php

session_start(); //starts the session
session_unset(); //removes all data stored in the session
session_destroy(); //destroys the session
header("Location: index.php"); //takes user back to the index.php (login/register page)
exit();

?>