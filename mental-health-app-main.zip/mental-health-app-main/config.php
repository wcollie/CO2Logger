<?php
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "Student_Mental_Health"; 

$conn = new mysqli($servername, $db_username, $db_password); //connects to MySQL

if ($conn->connect_error) { //checks connection
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS $dbname"; //creates database if it doesn't exist
if ($conn->query($sql) === FALSE) {
    die("Error creating database: " . $conn->error);
}

$conn->select_db($dbname); //selects database

//users table
$sql_users = "CREATE TABLE IF NOT EXISTS users ( 
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";
if ($conn->query($sql_users) === FALSE) {
    die("Error creating users table: " . $conn->error);
}

// therapy bookings table
$conn->query("CREATE TABLE IF NOT EXISTS therapy_bookings (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT  NOT NULL,
    session_date DATE NOT NULL,
    session_time TIME NOT NULL,
    notes        TEXT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_slot (session_date, session_time),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
)");
 