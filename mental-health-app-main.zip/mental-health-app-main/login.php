<?php
session_start(); //starts session
require_once 'config.php'; //calls config.php

if (isset($_POST['login'])) { //login form

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) { //checks if essential form parts are filled in 
        $_SESSION['login_error'] = 'Please enter both email and password'; //provides feedback for user
        header("Location: loginForm.php");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { //validates email format to prevent crash or issues
        $_SESSION['login_error'] = 'Invalid email format';
        header("Location: loginForm.php");
        exit();
    }

    $stmt = $conn->prepare("SELECT user_id, username, first_name, last_name, email, PASSWORD FROM users WHERE email = ?"); //query the user by the email
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();


    if ($result && $result->num_rows > 0) { //if a user is found
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['PASSWORD'])) { //verify password

            $_SESSION['user_id'] = $user['user_id']; //saves details
            $_SESSION['username'] = $user['username'];
            $_SESSION['firstName'] = $user['first_name'];
            $_SESSION['lastName'] = $user['last_name'];
            $_SESSION['email'] = $user['email'];

            header("Location: home.php"); //takes user to the home page
            exit();
        } else {
            $_SESSION['login_error'] = 'Incorrect password'; //provides feedback to user
        }
    } else {
        $_SESSION['login_error'] = 'No account found with the entered email'; //provides feedback to user
    }

    $stmt->close();
    header("Location: loginForm.php");
    exit(); //exits if statement
}
?>
