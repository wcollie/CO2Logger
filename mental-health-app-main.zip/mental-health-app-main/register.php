<?php
session_start(); //start session
require_once 'config.php'; //runs config.php file

if (isset($_POST['register'])) {

    $username = trim($_POST['username']);
    $first_name = trim($_POST['firstName']);
    $last_name = trim($_POST['lastName']);
    $email = trim($_POST['email']);
    $password_input = $_POST['password'];

   
    $errors = []; //validation

    if (empty($username) || empty($first_name) || empty($last_name) || empty($email) || empty($password_input)) {
        $errors[] = "Please fill in all required fields.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (strlen($username) < 4 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username must be at least 4 characters long and only contain letters, numbers, and underscores.";
    }

    if (
    strlen($password_input) < 8 ||!preg_match('/[A-Za-z]/', $password_input) ||!preg_match('/[0-9]/', $password_input) ||!preg_match('/[\W_]/', $password_input)
    ) {
    $errors[] = "Password must be at least 8 characters long and contain letters, at least one number, and at least one special character.";
    }

    if (!empty($errors)) {
        $_SESSION['register_error'] = implode("<br>", $errors);
        header("Location: registerForm.php");
        exit();
    }

    $password = password_hash($password_input, PASSWORD_DEFAULT); //hashes password for security

    $check = $conn->prepare("SELECT user_id FROM users WHERE email = ? OR username = ?"); //checks if email or username exists already
    $check->bind_param("ss", $email, $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $_SESSION['register_error'] = "Email or username already exists."; //provides feedback for user
        header("Location: registerForm.php"); //takes them back to register form
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO users (username, first_name, last_name, email, PASSWORD) VALUES (?, ?, ?, ?, ?)"); //inserts new user under correct column names
    $stmt->bind_param("sssss", $username, $first_name, $last_name, $email, $password);
    $stmt->execute();

    $_SESSION['register_success'] = "Registration successful! You can now login."; //provides feedback of successful login
    header("Location: loginForm.php"); //takes them to login form
    exit();
}
?>
