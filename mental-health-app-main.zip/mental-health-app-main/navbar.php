<div class="navbar">

    <h1>Mental Health App</h1>

    <ul class="nav-links">
        <li><a href="home.php">Home</a></li>
        <li><a href="therapy.php">Book Therapy Session</a></li>
        <li><a href="resources.php">Resources</a></li>
        <li><a href="chatbot.php">Chat Bot</a></li>
        <li></li><a class="logout" href="logout.php">Log Out</a></li>
    </ul>

</div>

