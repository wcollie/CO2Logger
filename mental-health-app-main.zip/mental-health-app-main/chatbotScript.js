const intents = [

    {
        type: "greeting",
        keywords: ["hello", "hi", "hey", "hiya", "good morning", "good afternoon"],
        response: "Hello! How are you feeling today?"
    },

    {
        type: "crisis",
        keywords: ["suicide", "kill myself", "hurt myself", "end it"],
        response: "I'm really sorry you're feeling this way. Please consider speaking to someone you trust or visit resources immediately. You are not alone."
    },

    {
        type: "negative_mood",
        keywords: ["sad","not good", "unhappy", "depressed", "down", "low mood"],
        response: "I'm really sorry you're feeling this way. You might find it helpful to talk to someone or book a therapy session or visit our resources page."
    },

    {
        type: "stress",
        keywords: ["stress", "stressed", "overwhelmed", "pressure", "burnt out"],
        response: "That sounds really stressful. Breathing excersises can help. You could think about a therapy session, taking a short break might help. Visit the resources page for more information."
    },

    {
        type: "anxiety",
        keywords: ["anxious", "anxiety", "worried", "nervous", "panic"],
        response: "That sounds tough. Talking to a professional or using breathing techniques might help. Check out our resources page for more help."
    },

    {
        type: "navigation",
        keywords: ["where", "how do i", "find", "access", "go to", "therapy"],
        response: "You can book a therapy session on the Book Therapy Session page or visit the Resources page for support."
    },
    
    {
        type: "refusal",
        keywords: ["no", "not now", "don't want", "leave me"],
        response: "That's okay. If you change your mind, support is always available through booking a therapy session or visting our resources page."
    },

    {
        type: "positive",
        keywords: ["good", "okay", "fine", "better", "happy", "great"],
        response: "I'm glad you're feeling better. I'm here if you ever need support."
    }
];


function getResponse(message){

    let text = message.toLowerCase();

    for(let intent of intents){

        for(let keyword of intent.keywords){

            if(text.includes(keyword)){

                let res = intent.response;
                if(Array.isArray(res)){
                    return res[Math.floor(Math.random() * res.length)];
                }

                return res;
            }

        }

    }

    return "Thanks for sharing. If you need support, you can book a therapy session or visit the Resources page.";
}


function sendMessage(){

    let input = document.getElementById("user-input");
    let message = input.value.trim();

    if(message === "") return;

    let chatBox = document.getElementById("chat-box");

    /* USER MESSAGE */

    let userDiv = document.createElement("div");
    userDiv.className = "user-message";
    userDiv.innerText = message;

    chatBox.appendChild(userDiv);

    input.value = "";

    /* BOT MESSAGE */

    let botDiv = document.createElement("div");
    botDiv.className = "bot-message";

    botDiv.innerText = getResponse(message);

    /* DELAY */

    setTimeout(function(){

        chatBox.appendChild(botDiv);
        chatBox.scrollTop = chatBox.scrollHeight;

    }, 600);

    chatBox.scrollTop = chatBox.scrollHeight;
}


document.getElementById("user-input")
.addEventListener("keypress", function(event){

    if(event.key === "Enter"){
        sendMessage();
    }

});