<?php
include("auth.php"); //runs auth.php
$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mental Health Chatbot</title>

    <link rel="stylesheet" href="chatbotStyle.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>

<?php include 'navbar.php'; ?>


<!--chatbot-->

<div class="chat-container">

    <div class="chat-header">
        Mental Health Support Bot
    </div>

    <div class="chat-box" id="chat-box">

        <div class="bot-message">
            Hello! How are you feeling today?
        </div>

    </div>

    <div class="input-area">

        <input
            type="text"
            id="user-input"
            placeholder="Type a message..."
        >

        <button onclick="sendMessage()">
            Send
        </button>

    </div>

</div>

<script src="chatbotScript.js"></script>

</body>

</html>