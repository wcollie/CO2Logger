<?php
include("auth.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Health App</title>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="resourcesStyle.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="resources-container">

    <h1>Mental Health Resources</h1>

    <p><h4>
        There are many resources out there to help you! You are not alone. These are so of the many resources out there:
    </p></h4>

    <ul class="resource-list">
        <li>
            <p>
                This is the Cardiff Metropolitan Unviversity Mental Health and Wellbeing website where they offer free, confidential mental health and wellbeing support.
            </p>
            <a href="https://www.cardiffmet.ac.uk/support/student-services/disability-mental-health-and-dyslexia/mental-health-and-wellbeing/" target="_blank">
                Cardiff Metropolitan Unviversity Mental Health and Wellbeing
            </a>
        </li>

        <li>
            <p>
                This is the Cardiff Metropolitan Unviversity Student Services website where you can find more resources to help you out.
            </p>
            <a href="https://www.cardiffmet.ac.uk/support/student-services/" target="_blank">
                Cardiff Metropolitan Unviversity Student Services
            </a>
        </li>

        <li>
            <p>
                This is the NHS Mental Health website where you can read about mental health conditions, adivce and get support
            </p>
            <a href="https://www.nhs.uk/mental-health/" target="_blank">
                NHS Mental Health Support
            </a>
        </li>

        <li>
            <p>
                This is the Mind Charity website where you can find adivce and get support
            </p>
            <a href="https://www.mind.org.uk/" target="_blank">
                Mind - Mental Health Charity
            </a>
        </li>

        <li>
            <p>
                This is the Samaritans website where you can call to speak to someone 24/7 to get help or have a conversation with someone who cares
            </p>
            <a href="https://www.samaritans.org/" target="_blank">
                Samaritans - 24/7 Support
            </a>
        </li>

        <li>
            <p>
                This is the YoungMinds website where as a young person you can find all the help and advice you need
            </p>
            <a href="https://www.youngminds.org.uk/" target="_blank">
                YoungMinds - Youth Mental Health
            </a>
        </li>
    </ul>

</div>

</body>
</html>