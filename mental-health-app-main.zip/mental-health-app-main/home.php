<?php
include("auth.php");
$user_id = $_SESSION['user_id'];

$conn = new mysqli("localhost", "root", "", "stepup"); // connects to database

$today = date("Y-m-d"); // today's date

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Health App</title>
    <link rel="stylesheet" href="style.css"> 
</head>
<body>

    <?php include 'navbar.php'; ?>

    <div class="hero-box">
        <h1>Mental Health App</h1>
        <p>Your mental health matters.</p>
    </div>

    <div class="features">
        <div class="feature-box">
            <h2>Book a Therapy Session</h2>
            <p>Schedule a session with a professional therapist.</p>
            <a href="therapy.php" class="button">Book Now</a>
        </div>

        <div class="feature-box">
            <h2>Resources</h2>
            <p>Explore helpful guides and mental health resources.</p>
            <a href="resources.php" class="button">View Resources</a>
        </div>

        <div class="feature-box">
            <h2>Chat Bot</h2>
            <p>Talk to our AI assistant for support and guidance.</p>
            <a href="chatbot.php" class="button">Start Chat</a>
        </div>
    </div>

</body>
</html>
