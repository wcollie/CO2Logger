<?php
session_start();

$error = $_SESSION['register_error'] ?? '';
$success = $_SESSION['register_success'] ?? '';
unset($_SESSION['register_error'], $_SESSION['register_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register - Student Mental Health</title>
  <link rel="stylesheet" href="startUpStyle.css">
</head>

<body>

<div class="card">

    <h2>Register</h2>

    <?php if (!empty($error)) : ?>
        <p class="error-message"><?= $error ?></p>
    <?php endif; ?>

    <?php if (!empty($success)) : ?>
        <p style="color:green;"><?= $success ?></p>
    <?php endif; ?>

    <form action="register.php" method="post">

        <input type="text" name="username" placeholder="Username" required>
        <input type="text" name="firstName" placeholder="First Name" required>
        <input type="text" name="lastName" placeholder="Last Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="register">Register</button>

        <p>Already have an account? <a href="loginForm.php">Login</a></p>

    </form>

</div>

</body>
</html>