<?php
session_start();

$error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - Student Mental Health App</title>
  <link rel="stylesheet" href="startUpStyle.css">
</head>

<body>

<div class="card">

    <h2>Login</h2>

    <?php if (!empty($error)) : ?>
        <p class="error-message"><?= $error ?></p>
    <?php endif; ?>

    <form action="login.php" method="post">

        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Login</button>

        <p>Don't have an account? <a href="registerForm.php">Register</a></p>

    </form>

</div>

</body>
</html>